<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Faculty;

class RoomPermissionPolicy
{
    /**
     * Check if the user can view the faculties.
     *
     * @param User $user
     * @return bool
     */
    public function views(User $user)
    {
        return $user->can('view_room_permissions');
    }

    /**
     * Check if the user can view a specific faculty.
     *
     * @param User $user
     * @return bool
     */
    public function view(User $user)
    {
        return $user->can('view_room_permission');
    }

    /**
     * Check if the user can create a faculty.
     *
     * @param User $user
     * @return bool
     */
    public function confirm(User $user)
    {
        return $user->can('confirm_room_permission');
    }

}
