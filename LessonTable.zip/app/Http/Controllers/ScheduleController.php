<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\Faculty;
use App\Models\Department;
use App\Models\Group;
use App\Models\Corp;
use App\Models\Room;
use App\Models\Lesson_Type;
use App\Models\Lesson_Type_Hour;
use App\Models\Hour;
use App\Models\Semester;
use App\Models\Week_Type;
use App\Models\Day;
use App\Models\User;
use App\Models\Discipline;
use Illuminate\Http\Request;

class ScheduleController extends Controller
{
    public function test()
    {
        $schedule = Schedule::with('lessonTypeHour')->get();
        return response()->json(['faculties' => $schedule]);
    }

    public function index()
    {
        $user = auth()->user(); // Giriş yapan kullanıcıyı al
        $result = [];
        $semester = Semester::where('status', 1)
        ->orderBy('id', 'desc')
        ->first();
        // Superadmin → Tüm fakülteleri görebilir
        if ($user->can('view_all_faculties')) {
            $faculties = Faculty::where('status', 1)->get();
        }
        // Fakülte Admini → Sadece kendi fakültesini görebilir
        elseif ($user->can('view_own_faculty')) {
            $faculties = Faculty::where('id', $user->faculty_id)->where('status', 1)->get();
        }
        // Öğretmen → Sadece kendi derslerini görebilir
        elseif ($user->can('view_own_lessons')) {
            $facultyIds = Schedule::where('user_id', $user->id)->where('semester_id', $semester->id)
                ->where('status', 1)->where('confirm_status', '!=', 2)
                ->pluck('faculty_id')
                ->unique()
                ->toArray();

            $faculties = Faculty::whereIn('id', $facultyIds)->where('status', 1)->get();
        } else {
            return response()->json(['message' => 'Yetkisiz erişim'], 403);
        }

        foreach ($faculties as $faculty) {
            $scheduleQuery = Schedule::with('group')
                ->where('faculty_id', $faculty->id)->where('semester_id', $semester->id)
                ->where('status', 1)->where('confirm_status', '!=', 2);

            // Fakülte admini sadece kendi eklediği dersleri görmeli
            if ($user->can('view_own_lessons')) {
                $scheduleQuery->where('user_id', $user->id)->where('semester_id', $semester->id);
            }

            $schedules = $scheduleQuery->get();

            // Grup bazlı dizi
            $groupedLessons = [];

            foreach ($schedules as $schedule) {
                $groupName = optional($schedule->group)->name ?? 'Bilinmeyen Grup';

                $groupedLessons[$groupName][] = [
                    'schedule_id' => $schedule->id,
                    'day_name' => optional($schedule->day)->name,
                    'hour_name' => optional($schedule->hour)->name,
                    'discipline_name' => optional($schedule->discipline)->name,
                    'user_name' => optional($schedule->user)->name,
                    'corp_name' => optional($schedule->corp)->name,
                    'group_name' => optional($schedule->group)->name,
                    'lesson_type_name' => optional($schedule->lessonType)->name,
                    'lesson_type_hour' => optional($schedule->lessonTypeHour)->hour,
                    'room_name' => optional($schedule->room)->name,
                    'year' => optional($schedule->semester)->year,
                    'semester_num' => optional($schedule->semester)->semester_num,
                    'confirm_status' => $schedule->confirm_status,
                    'week_type_name' => optional($schedule->weekType)->name,
                ];
            }

            $result[] = [
                'faculty_name' => $faculty->name,
                'faculty_id' => $faculty->id,
                'lessons' => $groupedLessons, // Gruplanmış dersleri fakülte içinde gönderiyoruz
            ];
        }

        return response()->json(['faculties' => $result]);
    }



    public function show($id)
    {
        $user = auth()->user();

        // Kullanıcının yetkisine göre ilgili dersi getirme
        if ($user->can('view_all_faculties')) {
            $schedule = Schedule::where('status', 1)->where('confirm_status', '!=', 2)->find($id);
        } elseif ($user->can('view_own_faculty')) {
            $schedule = Schedule::where('faculty_id', $user->faculty_id)->where('status', 1)->where('confirm_status', '!=', 2)->find($id);
        } elseif ($user->can('view_own_lessons')) {
            $schedule = Schedule::where('user_id', $user->id)->where('status', 1)->where('confirm_status', '!=', 2)->find($id);
        } else {
            return response()->json(['message' => 'Yetkisiz erişim'], 403);
        }

        if (!$schedule) {
            return response()->json(['message' => 'Schedule not found'], 404);
        }

        $formattedSchedule = [
            'id' => $schedule->id,
            'faculty_name' => optional($schedule->faculty)->name,
            'faculty_id' => optional($schedule->faculty)->id,
            'department_name' => optional($schedule->department)->name,
            'department_id' => optional($schedule->department)->id,
            'group_name' => optional($schedule->group)->name,
            'group_id' => optional($schedule->group)->id,
            'corp_name' => optional($schedule->corp)->name,
            'corp_id' => optional($schedule->corp)->id,
            'room_name' => optional($schedule->room)->name,
            'room_id' => optional($schedule->room)->id,
            'lesson_type_name' => optional($schedule->lessonType)->name,
            'lesson_type_id' => optional($schedule->lessonType)->id,
            'lesson_type_hour' => optional($schedule->lessonTypeHour)->hour,
            'lesson_type_hour_id' => optional($schedule->lessonTypeHour)->id,
            'hour_name' => optional($schedule->hour)->name,
            'hour_id' => optional($schedule->hour)->id,
            'year' => optional($schedule->semester)->year,
            'semester_num' => optional($schedule->semester)->semester_num,
            'semester_id' => optional($schedule->semester)->id,
            'week_type_name' => optional($schedule->weekType)->name,
            'week_type_id' => optional($schedule->weekType)->id,
            'day_name' => optional($schedule->day)->name,
            'day_id' => optional($schedule->day)->id,
            'user_name' => optional($schedule->user)->name,
            'user_id' => optional($schedule->user)->id,
            'discipline_name' => optional($schedule->discipline)->name,
            'discipline_id' => optional($schedule->discipline)->id,
        ];

        return response()->json(['schedule' => $formattedSchedule]);
    }


    public function store(Request $request)
    {
        $validated = $request->validate([
            'faculty_id' => 'required|integer|exists:faculties,id',
            'department_id' => 'required|integer|exists:departments,id',
            'group_id' => 'required|array',
            'group_id.*' => 'integer|exists:groups,id',
            'corp_id' => 'required|integer|exists:corps,id',
            'room_id' => 'required|integer|exists:rooms,id',
            'lesson_type_id' => 'required|integer|exists:lesson_types,id',
            'lesson_type_hour_id' => 'required|integer|exists:lesson_type_hours,id',
            'hour_id' => 'required|integer|exists:hours,id',
            'semester_id' => 'required|integer|exists:semesters,id',
            'week_type_id' => 'required|integer|exists:week_types,id',
            'day_id' => 'required|integer|exists:days,id',
            'user_id' => 'required|integer|exists:users,id',
            'discipline_id' => 'required|integer|exists:disciplines,id',
        ]);

        // Kullanıcının aynı semester, hafta, gün ve saatte dersi var mı?
        $existingUserSchedule = Schedule::where('status', 1)->where('confirm_status', '!=', 2)->where('user_id', $validated['user_id'])
            ->where('hour_id', $validated['hour_id'])
            ->where('semester_id', $validated['semester_id'])
            ->where('week_type_id', $validated['week_type_id'])
            ->where('day_id', $validated['day_id'])
            ->get();

        foreach ($existingUserSchedule as $schedule) {
            // Eğer aynı derse aitse ve muhazire (lesson_type_id = 1) ise farklı odalara izin verme
            if (
                $schedule->lesson_type_id == 1 &&
                $schedule->room_id != $validated['room_id']
            ) {
                return response()->json([
                    'message' => 'Eyni semester, həftə, gün və saatda fərqli otaqda muhazire əlavə edə bilməzsiniz.'
                ], 403);
            }
        }

        // Oda doluluk kontrolü
        $roomControl = Schedule::where('status', 1)->where('confirm_status', '!=', 2)->where('room_id', $validated['room_id'])
            ->where('hour_id', $validated['hour_id'])
            ->where('semester_id', $validated['semester_id'])
            ->where('week_type_id', $validated['week_type_id'])
            ->where('day_id', $validated['day_id'])
            ->get();

        foreach ($roomControl as $schedule) {
            // Eğer ders muhazire (lesson_type_id = 2) değilse ve aynı user tarafından eklenmemişse izin verme
            if (
                $schedule->lesson_type_id != 1 &&  // Ders muhazire değilse
                $schedule->user_id != $validated['user_id'] // Farklı bir kullanıcı eklemişse
            ) {
                return response()->json([
                    'message' => 'Seçilmiş otaq eyni semester, həftə, gün və saat üçün artıq doludur.'
                ], 403);
            }
        }

        $room = Room::findOrFail($validated['room_id']);
        $confirmStatus = $room->room_type_id == 2 ? 0 : 1; // Oda türüne göre onay durumu belirleniyor.

        // Schedule verilerinin topluca hazırlanması
        $schedulesData = collect($validated['group_id'])->map(function ($groupId) use ($validated, $confirmStatus) {
            return [
                'faculty_id' => $validated['faculty_id'],
                'department_id' => $validated['department_id'],
                'group_id' => $groupId,
                'corp_id' => $validated['corp_id'],
                'room_id' => $validated['room_id'],
                'lesson_type_id' => $validated['lesson_type_id'],
                'lesson_type_hour_id' => $validated['lesson_type_hour_id'],
                'hour_id' => $validated['hour_id'],
                'semester_id' => $validated['semester_id'],
                'week_type_id' => $validated['week_type_id'],
                'day_id' => $validated['day_id'],
                'user_id' => $validated['user_id'],
                'discipline_id' => $validated['discipline_id'],
                'status' => 1, // Varsayılan olarak aktif.
                'confirm_status' => $confirmStatus, // Onay durumu.
                'created_at' => now(),
                'updated_at' => now(),
            ];
        });

        // Tüm verilerin topluca veritabanına yazılması
        Schedule::insert($schedulesData->toArray());

        return response()->json([
            'message' => 'Schedules created successfully and pending approval.',
        ], 201);
    }

    public function update(Request $request, $id)
    {
        // Validation
        $validated = $request->validate([
            'faculty_id' => 'required|integer|exists:faculties,id',
            'department_id' => 'required|integer|exists:departments,id',
            'group_id' => 'required|integer|exists:groups,id', // Artık array değil
            'corp_id' => 'required|integer|exists:corps,id',
            'room_id' => 'required|integer|exists:rooms,id',
            'lesson_type_id' => 'required|integer|exists:lesson_types,id',
            'lesson_type_hour_id' => 'required|integer|exists:lesson_type_hours,id',
            'hour_id' => 'required|integer|exists:hours,id',
            'semester_id' => 'required|integer|exists:semesters,id',
            'week_type_id' => 'required|integer|exists:week_types,id',
            'day_id' => 'required|integer|exists:days,id',
            'user_id' => 'required|integer|exists:users,id',
            'discipline_id' => 'required|integer|exists:disciplines,id',
        ]);

        // Güncellenecek Schedule kaydını bul
        $schedule = Schedule::findOrFail($id);

        // Oda kontrolü (çakışma kontrolü)
        $roomConflict = Schedule::where('status', 1)->where('confirm_status', '!=', 2)->where('room_id', $validated['room_id'])
            ->where('hour_id', $validated['hour_id'])
            ->where('semester_id', $validated['semester_id'])
            ->where('week_type_id', $validated['week_type_id'])
            ->where('day_id', $validated['day_id'])
            ->where('id', '!=', $schedule->id) // Kendisi hariç
            ->exists();

        if ($roomConflict) {
            return response()->json([
                'message' => 'Daxil etdiyiniz parametrlərlə seçdiyiniz otaq doludur',
            ], 403);
        }

        // Oda türüne göre confirm_status belirle
        $room = Room::findOrFail($validated['room_id']);
        $confirmStatus = $room->room_type_id == 2 ? 0 : 1;

        // Güncelleme işlemi
        $schedule->update([
            'faculty_id' => $validated['faculty_id'],
            'department_id' => $validated['department_id'],
            'group_id' => $validated['group_id'], // Direkt tekil ID atanıyor
            'corp_id' => $validated['corp_id'],
            'room_id' => $validated['room_id'],
            'lesson_type_id' => $validated['lesson_type_id'],
            'lesson_type_hour_id' => $validated['lesson_type_hour_id'],
            'hour_id' => $validated['hour_id'],
            'semester_id' => $validated['semester_id'],
            'week_type_id' => $validated['week_type_id'],
            'day_id' => $validated['day_id'],
            'user_id' => $validated['user_id'],
            'discipline_id' => $validated['discipline_id'],
            'confirm_status' => $confirmStatus,
            'updated_at' => now(),
        ]);

        return response()->json([
            'message' => 'Schedule updated successfully.',
        ], 200);
    }


    public function destroy($id)
    {
        $schedule = Schedule::findOrFail($id);
        $schedule->update(['status' => '0']);
        return response()->json(['message' => 'Schedule deleted successfully']);
    }


    public function getDepartmentsByFaculty($faculty_id)
    {
        $faculty = Faculty::where('status', '1')->find($faculty_id);
        if (!$faculty) {
            return response()->json(['message' => 'Faculty not found'], 404);
        }
        $departments = $faculty->departments()->where('status', 1)->get();
        return response()->json($departments);
    }
    public function getGroupsByFaculty($faculty_id)
    {
        $faculty = Faculty::where('status', '1')->find($faculty_id);

        if (!$faculty) {
            return response()->json(['message' => 'Faculty not found'], 404);
        }

        $groups = $faculty->groups()->where('status', '1')->get();

        return response()->json($groups);
    }
    public function getDisciplinesByDepartment($department_id)
    {
        $department = Department::where('status', '1')->find($department_id);

        if (!$department) {
            return response()->json(['message' => 'Department not found'], 404);
        }

        $disciplines = $department->disciplines()->where('status', 1)->get();

        return response()->json($disciplines);
    }
    public function getUsersByDepartment($department_id)
    {
        $department = Department::where('status', '1')->find($department_id);

        if (!$department) {
            return response()->json(['message' => 'Department not found'], 404);
        }

        $users = $department->users()->where('status', 1)->get();

        return response()->json($users);
    }
    public function filterSchedules(Request $request)
    {
        $facultyId = $request->input('faculty_id');
        $schedulesQuery = Schedule::where('status', '1');

        if ($facultyId) {
            $schedulesQuery->where('faculty_id', $facultyId);
        }

        $schedules = $schedulesQuery->with([
            'faculty',
            'department',
            'group',
            'corp',
            'room',
            'lessonType',
            'hour',
            'semester',
            'weekType',
            'day',
            'user',
            'discipline',
        ])->get();

        return response()->json(['schedules' => $schedules]);
    }
}
