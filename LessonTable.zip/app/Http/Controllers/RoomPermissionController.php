<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Faculty;
use Illuminate\Http\Request;
use App\Models\RoomPermission;
use App\Models\Schedule;
use App\Models\Speciality;

class RoomPermissionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
        $this->middleware('can:confirm,App\Models\RoomPermission')->only(['store']);
        $this->middleware('can:views,App\Models\RoomPermission')->only(['index']);
        $this->middleware('can:view,App\Models\RoomPermission')->only(['show']);
    }

    public function index()
    {
        //fakulte admini 
        $RoomPermission = Schedule::whereIn('confirm_status', [0, 2])
        ->with([
            'faculty',
            'department',
            'group',
            'corp',
            'room',
            'lessonType',
            'lessonTypeHour',
            'hour',
            'semester',
            'weekType',
            'day',
            'user',
            'discipline',
        ])
        ->get();
        return response()->json($RoomPermission);
    }


    public function show($id)
    {
        $RoomPermission = Schedule::whereIn('confirm_status', [0, 2])->with([
            'faculty',
            'department',
            'group',
            'corp',
            'room',
            'lessonType',
            'lessonTypeHour',
            'hour',
            'semester',
            'weekType',
            'day',
            'user',
            'discipline',
        ])->find($id);

        return response()->json($RoomPermission);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'schedule_id' => 'required|integer|exists:schedules,id',
            'reply' => 'required|integer|in:1,2',
        ]);
        $RoomPermission = Schedule::where('confirm_status', 0)->find($validated['schedule_id']);
        if ($RoomPermission) {
            $RoomPermission->update([
                'confirm_status' => $validated['reply']
            ]);
        }
        if ($validated['reply'] == 2) {
            return response()->json([
                'message' => 'Schedule remove successfully.',
            ], 200);
        }
        if ($validated['reply'] == 1) {
            return response()->json([
                'message' => 'Schedule accepted successfully.',
            ], 200);
        }
    }
}
