<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Lesson_Type_Hour;
use Illuminate\Http\Request;

class LessonTypeHourController extends Controller
{
   
    public function index()
    {
        //die();
        $LessonTypeHour = Lesson_Type_Hour::get();
        return response()->json($LessonTypeHour);
    }
}
